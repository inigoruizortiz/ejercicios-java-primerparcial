import java.util.Arrays;
import java.util.List;

import javax.swing.table.DefaultTableModel;

public class ModeloTablaVehiculos extends DefaultTableModel{
	private List<String> lTitulos = Arrays.asList("MATRÍCULA","COLOR","CONSUMO","VEL. MAX");
	private List<Vehiculo> lVehiculos;
	
	public ModeloTablaVehiculos(List<Vehiculo> l) {
		lVehiculos = l;
	}

	@Override
	public int getRowCount() {
		if(lVehiculos == null) {
			return 0;
		}else {
			return lVehiculos.size();
		}
	}

	@Override
	public int getColumnCount() {
		return lTitulos.size();
	}

	@Override
	public String getColumnName(int column) {
		return lTitulos.get(column);
	}

	@Override
	public boolean isCellEditable(int row, int column) {
		if(column == 3) {
			return true;
		}else {
			return false;
		}
	}

	@Override
	public Object getValueAt(int row, int column) {
		Vehiculo v = lVehiculos.get(row);
		switch(column) {
			case 0: return v.getMatricula();
			case 1: return v.getColor();
			case 2: return v.getConsumo();
			case 3: return v.getVelMax();
			default: return null;
		}
	}
	
	
}










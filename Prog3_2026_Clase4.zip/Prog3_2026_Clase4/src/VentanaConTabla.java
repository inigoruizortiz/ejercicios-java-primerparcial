import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellRenderer;


public class VentanaConTabla extends JFrame{
	private JPanel pNorte, pSur;
	private List<Vehiculo> lVehiculos;
	
	private JButton btnMostrarTodos, btnSalir;
	
	//Atributos de la JTable
	private ModeloTablaVehiculos modeloTabla;
	private JTable tabla;
	private JScrollPane scrollTabla;
	
	//Atributos para la lista desplegable
	private JComboBox<ColorCoche> cbColores;
	
	public VentanaConTabla(List<Vehiculo> l) {
		super();
		lVehiculos = l;
		//Propiedades de la ventana
		setBounds(300, 200, 800, 200);
		setTitle("TABLA DE VEHÍCULOS");
		
		//Creación de los paneles
		pNorte = new JPanel();
		pSur = new JPanel();
		
		//Añadir los paneles a la ventana
		getContentPane().add(pNorte, BorderLayout.NORTH);
		getContentPane().add(pSur,BorderLayout.SOUTH);
		
		//Creación de los componentes
		
		btnMostrarTodos = new JButton("Mostrar Todos");
		
		modeloTabla = new ModeloTablaVehiculos(lVehiculos);
		tabla = new JTable(modeloTabla);
		scrollTabla = new JScrollPane(tabla);
		
		cbColores = new JComboBox<ColorCoche>(ColorCoche.values()); //Creamos el comboBox con los colores de la enumeración ColorCoche
		
		//Crear un botón con una imagen
		btnSalir = new JButton("Salir");
		
		//Añadimos los componentes a los paneles/ventana
		pNorte.add(cbColores);
		pNorte.add(btnMostrarTodos);
		pSur.add(btnSalir);
		add(scrollTabla, BorderLayout.CENTER); //Añado el scroll que contiene la tabla al centro de la ventana
		
		//Listeners
		cbColores.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				//Obtenemos el color seleccionado por el usuario
				ColorCoche c = (ColorCoche) cbColores.getSelectedItem();
				List<Vehiculo> lFiltrados = new ArrayList<Vehiculo>();
				for(Vehiculo v: lVehiculos) { //Recorremos todos los vehículos de la lista de vehículos
					if(v.getColor().equals(c)) { //Cada vez que el color de un vehículo sea el seleccionado por el usuario
						lFiltrados.add(v); //Lo añadirmos a la lista de vehículos filtrados
					}
				}
				modeloTabla = new ModeloTablaVehiculos(lFiltrados);
				tabla.setModel(modeloTabla);
			}
		});
		
		btnMostrarTodos.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				modeloTabla = new ModeloTablaVehiculos(lVehiculos);
				tabla.setModel(modeloTabla);
				
			}
		});
		
		//Renderer de la JTable
		tabla.setDefaultRenderer(Object.class, new TableCellRenderer() {
			
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,
					int row, int column) {
				JLabel l = new JLabel(value.toString());
				l.setOpaque(true);
				if(column == 2) {
					float consumo = Float.parseFloat(value.toString());
					if(consumo > 7) {
						l.setForeground(Color.RED);
					}else {
						l.setForeground(Color.BLACK);
					}
				}else if(column == 1) {
					if(value.equals(ColorCoche.AMARILLO)) {
						l.setBackground(Color.YELLOW);
					}else if(value.equals(ColorCoche.AZUL)) {
						l.setBackground(Color.BLUE);
						l.setForeground(Color.WHITE);
					}if(value.equals(ColorCoche.BLANCO)) {
						l.setBackground(Color.WHITE);
					}if(value.equals(ColorCoche.NEGRO)) {
						l.setBackground(Color.BLACK);
						l.setForeground(Color.WHITE);
					}if(value.equals(ColorCoche.ROJO)) {
						l.setBackground(Color.RED);
					}if(value.equals(ColorCoche.VERDE)) {
						l.setBackground(Color.GREEN);
					} 
				}
				return l;
			}
		});
		setVisible(true);
	}
	
	public static void main(String[] args) {
		List<Vehiculo> l = new ArrayList<>();
		l.add(new Vehiculo("1111AAA", ColorCoche.AZUL, 9.8, 230));
		l.add(new Vehiculo("2222BBB", ColorCoche.AMARILLO, 5.8, 170));
		l.add(new Vehiculo("3333CCC", ColorCoche.BLANCO, 7.2, 190));
		l.add(new Vehiculo("4444DDD", ColorCoche.BLANCO, 6.7, 250));
		l.add(new Vehiculo("5555EEE", ColorCoche.NEGRO, 4.8, 180));
		l.add(new Vehiculo("6666FFF", ColorCoche.AZUL, 6.1, 220));
		new VentanaConTabla(l);
	}

}





























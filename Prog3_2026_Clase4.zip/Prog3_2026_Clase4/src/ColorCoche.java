
public enum ColorCoche {
	BLANCO,NEGRO,AZUL,AMARILLO,VERDE, ROJO
	
}

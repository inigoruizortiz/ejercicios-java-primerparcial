
public class Vehiculo {
	private String matricula;
	private ColorCoche color;
	private double consumo;
	private double velMax;

	public Vehiculo() {
	
	}
	
	public Vehiculo(String matricula, ColorCoche color, double consumo, double velMax) {
		super();
		this.matricula = matricula;
		this.color = color;
		this.consumo = consumo;
		this.velMax = velMax;
	}
	
	public String getMatricula() {
		return matricula;
	}
	
	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	
	public ColorCoche getColor() {
		return color;
	}
	
	public void setColor(ColorCoche color) {
		this.color = color;
	}
	
	public double getConsumo() {
		return consumo;
	}
	
	public void setConsumo(double consumo) {
		this.consumo = consumo;
	}
	
	public double getVelMax() {
		return velMax;
	}
	
	public void setVelMax(double velMax) {
		this.velMax = velMax;
	}
	
	@Override
	public String toString() {
		return "Vehiculo [matricula=" + matricula + ", color=" + color + ", consumo=" + consumo + ", velMax=" + velMax
				+ "]";
	}
	
	
}

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class VentanaInicial extends JFrame{
	//Declaración de componentes
	private JButton btnCerrar, btnIniciarSesion;
	private JLabel lblTitulo,lblNombreUsuario,lblContrasenia;
	private JTextField txtNombreUsuario, txtContrasenia;
	
	//Declaración de paneles
	private JPanel pNorte,pSur,pCentro,pEste,pOeste,pCentroArriba,pCentroAbajo;
	
	public VentanaInicial() {
		super();
		//Asignar las dimensiones a la ventana
		//coordenada x, coordenada y, ancho, alto
		setBounds(300, 200, 600, 400);
		//Evitar que la ventana pueda redimensionarse
		setResizable(false);
		//Evitar que la ventana se pueda cerrar
		setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		
		//Creación de paneles
		pNorte = new JPanel();
		pSur = new JPanel();
		pCentro = new JPanel();
		pCentro.setLayout(new GridLayout(2, 1)); //Dividimos el panel en 2 filas y 1 columna
		pEste = new JPanel();
		pOeste = new JPanel();
		pCentroArriba = new JPanel();
		pCentroAbajo = new JPanel();
		pCentro.add(pCentroArriba);
		pCentro.add(pCentroAbajo);
		
		//Asignación de los paneles a la ventana
		add(pNorte, BorderLayout.NORTH);
		add(pSur, BorderLayout.SOUTH);
		add(pCentro, BorderLayout.CENTER);
		add(pEste, BorderLayout.EAST);
		add(pOeste, BorderLayout.WEST);
		
		
		//Creación de componentes
		btnCerrar = new JButton("SALIR");
		lblTitulo = new JLabel("ONGI ETORRI!!");
		lblNombreUsuario = new JLabel("Introduce tu nombre de usuario: ");
		lblContrasenia = new JLabel("Introduce tu contraseña: ");
		txtNombreUsuario = new JTextField(20);
		txtContrasenia = new JTextField(20);
		btnIniciarSesion = new JButton("INICIAR SESIÓN");
		
		
		
		//Propiedades de los componentes
		lblTitulo.setForeground(Color.CYAN); //Modificaar el color de la letra
		lblTitulo.setForeground(new Color(200, 170, 56)); //Modificar el color de la letra usando los valores RGB
		//                           tipo de letra , negrita/cursiva/texto plano, tamaño
		//                                           Font.BOLD -> negrita
		//                                           Font.ITALIC -> cursiva
		//                                           Font.PLAIN -> texto plano
		lblTitulo.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20)); //Modificar la fuente
		
		//Asignación de los componentes a los paneles
		pSur.add(btnIniciarSesion);
		pSur.add(btnCerrar);
		pNorte.add(lblTitulo);
		pCentroArriba.add(lblNombreUsuario);
		pCentroArriba.add(txtNombreUsuario);
		pCentroAbajo.add(lblContrasenia);
		pCentroAbajo.add(txtContrasenia);
		
		//Programación de los listeners
		btnCerrar.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				//Código a ejecutar cuando se clicke sobre el botón
				System.exit(0); //Cerrar la aplicación
			}
		});
		
		btnIniciarSesion.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// Si el usuario teclea como nombre de usuario Prog3 y contraseña Prog3 se inicia sesión,
				// en caso contrario, mensaje de error
				String nombre = txtNombreUsuario.getText(); //Obtengo el texto escrito por el usuario en txtNombreUsuario
				String contrasenia = txtContrasenia.getText();
				if(nombre.equals("Prog3") && contrasenia.equals("Prog3")) {
					//System.out.println("Has iniciado sesión");
					JOptionPane.showMessageDialog(null, "Has iniciado sesión");
				}else {
					//System.out.println("Nombre de usuario y/o contraseña incorrectos");
					JOptionPane.showMessageDialog(null, "Nombre de usuario y/o contraseña incorrectos");
				}
				
			}
		});
		
		setVisible(true);
	}
	
	public static void main(String[] args) {
		new VentanaInicial();
	}
}






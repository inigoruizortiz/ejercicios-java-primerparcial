import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Ventana2 extends JFrame{
	private JPanel panelCentro,panelSur;
	private JLabel [] aEtiquetas; //Array de etiquetas
	private JButton btnCambiarColorTexto, btnCambiarColorFondo;
	
	public Ventana2() {
		super();
		//Propiedades de la ventana
		setBounds(400, 200, 600, 400);
		setTitle("NEWTON");
		ImageIcon im = new ImageIcon("img/titulo.png");
		setIconImage(im.getImage());
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setResizable(false);
		
		//Creación de paneles
		//número de filas, número de columnas, espacio horizontal, espacio vertical
		panelCentro = new JPanel(new GridLayout(3, 4, 20, 20));
		add(panelCentro, BorderLayout.CENTER);
		panelCentro.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY, 5));
		panelSur = new JPanel();
		add(panelSur, BorderLayout.SOUTH);
		
		//Creación de componentes
		aEtiquetas = new JLabel[12]; //Indicamos que el array tiene 12 posiciones
		for(int i=1;i<=12;i++) {
			aEtiquetas[i-1] = new JLabel(String.valueOf(i));
			aEtiquetas[i-1].setHorizontalAlignment(JLabel.CENTER);
			aEtiquetas[i-1].setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY));
			aEtiquetas[i-1].setOpaque(true);
			panelCentro.add(aEtiquetas[i-1]);
		}
		btnCambiarColorTexto = new JButton("CAMBIAR COLOR TEXTO");
		panelSur.add(btnCambiarColorTexto);
		
		btnCambiarColorFondo = new JButton("CAMBIAR COLOR FONDO");
		panelSur.add(btnCambiarColorFondo);
		
		//Listeners
		btnCambiarColorTexto.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				for(int i=1;i<=12;i++) {
					if(aEtiquetas[i-1].getForeground().equals(Color.GREEN)) {
						aEtiquetas[i-1].setForeground(Color.BLACK);
					}else {
						aEtiquetas[i-1].setForeground(Color.GREEN);
					}
				}
			}
		});
		
		btnCambiarColorFondo.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				for(int i=1;i<=12;i++) {
					aEtiquetas[i-1].setBackground(Color.YELLOW);
				}
			}
		});
		
		btnCambiarColorFondo.addMouseListener(new MouseListener() {
			
			@Override
			public void mouseReleased(MouseEvent e) {
				// Qué queremos que haga cuando dejamos del presionar el botón
				
			}
			
			@Override
			public void mousePressed(MouseEvent e) {
				// Qué queremos que haga cuando presionamos sobre el botón
				
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
				// Qué queremos que haga cuando el puntero del ratón sale del botón
				
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
				// Qué queremos que haga cuando el puntero del ratón entra al botón
				
			}
			
			@Override
			public void mouseClicked(MouseEvent e) {
				// Qué queremos que haga cuando hacemos click sobre el botón
				if(e.getClickCount() == 2) {
					for(int i=1;i<=12;i++) {
						aEtiquetas[i-1].setBackground(Color.LIGHT_GRAY);
					}
				}
			}
		});
		
		/*
		 * Cuando haga click con el botón izquierdo, que cambie el color de fondo de las etiquetas de
		 * valor par.
		 * Cuando haga click con el botón derechi, que cambie el color de fondo de las etiquetas de
		 * valor impar.
		 * */
		
		
		setVisible(true);
	}
	
	public static void main(String[] args) {
		Ventana2 v = new Ventana2();
	}
}











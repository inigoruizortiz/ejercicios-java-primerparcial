import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Ventana extends JFrame {
	private JPanel pNorte, pCentro, pSur;
	private JLabel lblTexto1, lblTexto2, lblTexto3, lblFoto1, lblFoto2, lblFoto3;
	private JButton btnIniciar1, btnIniciar2, btnIniciar3;
	private Thread hilo1, hilo2, hilo3;
	private boolean pausa1, pausa2, pausa3;
	public Ventana() {
		super();

		// Propiedades de la ventana
		setBounds(300, 300, 600, 200);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setResizable(false);

		// Creación de paneles
		pNorte = new JPanel(new GridLayout(1, 3));
		pCentro = new JPanel();
		pCentro.setLayout(new GridLayout(1, 3));
		pSur = new JPanel(new GridLayout(1, 3));
		add(pNorte, BorderLayout.NORTH);
		add(pSur, BorderLayout.SOUTH);
		add(pCentro, BorderLayout.CENTER);

		// Creación de componentes
		lblTexto1 = new JLabel("IMAGEN 1");
		lblTexto1.setHorizontalAlignment(JLabel.CENTER);
		lblTexto2 = new JLabel("IMAGEN 2");
		lblTexto2.setHorizontalAlignment(JLabel.CENTER);
		lblTexto3 = new JLabel("IMAGEN 3");
		lblTexto3.setHorizontalAlignment(JLabel.CENTER);
		pNorte.add(lblTexto1);
		pNorte.add(lblTexto2);
		pNorte.add(lblTexto3);

		btnIniciar1 = new JButton("INICIAR 1");
		btnIniciar2 = new JButton("INICIAR 2");
		btnIniciar3 = new JButton("INICIAR 3");
		pSur.add(btnIniciar1);
		pSur.add(btnIniciar2);
		pSur.add(btnIniciar3);

		lblFoto1 = new JLabel();
		lblFoto1.setHorizontalAlignment(JLabel.CENTER);
		lblFoto2 = new JLabel();
		lblFoto2.setHorizontalAlignment(JLabel.CENTER);
		lblFoto3 = new JLabel();
		lblFoto3.setHorizontalAlignment(JLabel.CENTER);
		pCentro.add(lblFoto1);
		pCentro.add(lblFoto2);
		pCentro.add(lblFoto3);

		pausa1 = true;
		pausa2 = true;
		pausa3 = true;
		
		hilo1 = new Thread(new Runnable() {

			@Override
			public void run() {
				while (true) {
					System.out.println();
					if(pausa1 == false) {
						int num = (int) (Math.random() * 15 + 1);
						String nombreFoto = "images/" + num + ".png";
						ImageIcon im = new ImageIcon(nombreFoto);
						lblFoto1.setIcon(im);
						try {
							Thread.sleep(500);
						} catch (InterruptedException e) {
							//e.printStackTrace();
						}
					}
				}
			}
		});
		hilo1.start();

		hilo2 = new Thread(new Runnable() {

			@Override
			public void run() {
				while (true) {
					System.out.println();
					if(pausa2 == false) {
						int num = (int) (Math.random() * 15 + 1);
						String nombreFoto = "images/" + num + ".png";
						ImageIcon im = new ImageIcon(nombreFoto);
						lblFoto2.setIcon(im);
						try {
							Thread.sleep(500);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
				}
			}
		});
		hilo2.start();

		hilo3 = new Thread(new Runnable() {

			@Override
			public void run() {
				while (true) {
					System.out.println();
					if(pausa3 == false) {
						int num = (int) (Math.random() * 15 + 1);
						String nombreFoto = "images/" + num + ".png";
						ImageIcon im = new ImageIcon(nombreFoto);
						lblFoto3.setIcon(im);
						try {
							Thread.sleep(500);
						} catch (InterruptedException e) {
							//e.printStackTrace();
						}
					}
				}
			}
		});
		hilo3.start();

		// Listeners
		btnIniciar1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if(btnIniciar1.getText().equals("INICIAR 1")) {
					pausa1 = false;
					btnIniciar1.setText("PAUSAR 1");
				}else {
					pausa1 = true;
					btnIniciar1.setText("INICIAR 1");
				}
			}
		});

		btnIniciar2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if(btnIniciar2.getText().equals("INICIAR 2")) {
					pausa2 = false;
					btnIniciar2.setText("PAUSAR 2");
				}else {
					pausa2 = true;
					btnIniciar2.setText("INICIAR 2");
				}
			}
		});
		btnIniciar3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if(btnIniciar3.getText().equals("INICIAR 3")) {
					pausa3 = false;
					btnIniciar3.setText("PAUSAR 1");
				}else {
					pausa3 = true;
					btnIniciar3.setText("INICIAR 3");
				}
			}
		});
		setVisible(true);
	}

	public static void main(String[] args) {
		new Ventana();
	}

}

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Ventana extends JFrame{
	private JPanel pCentro,pIzda,pDcha,pNorte;
	private JLabel lblReloj;
	
	public Ventana() {
		super();
		
		//Propiedades de la ventana
		setBounds(300, 200, 600, 400);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		//Creación de paneles
		pCentro = new JPanel(new GridLayout(1, 2));
		pIzda = new JPanel();
		pIzda.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		pDcha = new JPanel();
		pDcha.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		pCentro.add(pIzda);
		pCentro.add(pDcha);
		add(pCentro, BorderLayout.CENTER);
		pNorte = new JPanel();
		add(pNorte, BorderLayout.NORTH);
		lblReloj = new JLabel();
		pNorte.add(lblReloj);
		
		//Creación de threads
		Thread tReloj = new Thread(new Runnable() {
			
			@Override
			public void run() {
				SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
				while(true) {
					Date fechaActual = new Date();
					lblReloj.setText(sdf.format(fechaActual));
				}
			}
		});
		tReloj.start();
		
		Thread t1 = new Thread(new Runnable() {
			
			@Override
			public void run() {
				while(true) {
					pIzda.setBackground(Color.GREEN);
					try {
						Thread.sleep(5000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					pIzda.setBackground(Color.WHITE);
					try {
						Thread.sleep(5000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		});
		
		Thread t2 = new Thread(new Runnable() {
			
			@Override
			public void run() {
				while(true) {
					pDcha.setBackground(Color.RED);
					try {
						Thread.sleep(5000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					pDcha.setBackground(Color.WHITE);
					try {
						Thread.sleep(5000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		});
		
		t1.start();
		t2.start();
	
		setVisible(true);
	
	}
	
	public static void main(String[] args) {
		new Ventana();
	}

}

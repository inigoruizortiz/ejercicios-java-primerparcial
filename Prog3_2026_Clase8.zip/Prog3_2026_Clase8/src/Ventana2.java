import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Ventana2 extends JFrame{
	private JPanel pCentro,pSur;
	private JButton btnInicio, btnFin;
	
	private final Object monitor = new Object();
	private boolean pausa;
	
	public Ventana2() {
		super();
		
		//Propiedades de la ventana
		setBounds(300, 300, 600, 400);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		//Creación de paneles
		pCentro = new JPanel();
		pSur = new JPanel();
		add(pCentro, BorderLayout.CENTER);
		add(pSur, BorderLayout.SOUTH);
		
		//Creación de componentes
		btnInicio = new JButton("INICIO");
		btnFin = new JButton("FIN");
		pSur.add(btnInicio);
		pSur.add(btnFin);
		
		pausa = true;
		
		Thread hilo = new Thread(new Runnable() {
			
			@Override
			public void run() {
				while(true) {
					synchronized (monitor) {
						if(pausa == true) {
							try {
								monitor.wait();
							} catch (InterruptedException e) {
								e.printStackTrace();
							}
						}else {
							pCentro.setBackground(Color.LIGHT_GRAY);
							try {
								Thread.sleep(1000);
							} catch (InterruptedException e) {
								e.printStackTrace();
							}
							pCentro.setBackground(Color.WHITE);
							try {
								Thread.sleep(1000);
							} catch (InterruptedException e) {
								e.printStackTrace();
							}
						}
					}
					
				}
			}
		});
		hilo.start();
		btnInicio.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				synchronized (monitor) {
					pausa = false;
					monitor.notifyAll();
				}
			}
		});
		
		btnFin.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				synchronized (monitor) {
					pausa = true;
					monitor.notifyAll();
				}
				
			}
		});
		
		
		setVisible(true);
		
	}
	
	public static void main(String[] args) {
		new Ventana2();
	}

}













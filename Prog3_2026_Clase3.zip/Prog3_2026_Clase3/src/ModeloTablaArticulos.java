import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.table.DefaultTableModel;

public class ModeloTablaArticulos extends DefaultTableModel{
	private List<String> titulos = Arrays.asList("ID","NOMBRE","SECCIÓN","ESTANTERÍA","PRECIO");
	private ArrayList<Articulo> lArticulos;
	
	public ModeloTablaArticulos(ArrayList<Articulo> la) {
		lArticulos = la;
	}

	@Override
	public int getRowCount() {
		//Tenemos que devolver el número de filas que queremos que tenga la tabla
		if(lArticulos == null) { //si la lista de artículos no estuviera creada
			return 0; //Devolvemos 0 filas
		}else { //Si la lista de artículos ya está creada
			return lArticulos.size(); //Devolvemos tantas filas como artículos hay en la lista de artículos
		}
	}

	@Override
	public int getColumnCount() {
		//Tenemos que devolver el número de columnas que queremos que tenga la tabla
		return titulos.size(); //La tabla tendrá tantas columnas como título haya en el array titulos
	}

	@Override
	public String getColumnName(int column) {
		//Tiene que devolver el título que queremos que aparezca en el columna cuyo
		//número recibe por parámetro
		return titulos.get(column);
	}

	@Override
	public boolean isCellEditable(int row, int column) {
		//Recibe el número fila y columna de una celda y tenemos que 
		//devolver true si queremos que la celda sea editable y false en caso contrario
		return false; //Ninguna celda de la tabla es editable
	}

	@Override
	public Object getValueAt(int row, int column) {
		//Recibe el número de fila y columna de una celda y tiene que devolver la información (el dato)
		//que queremos que se muestre en esa celda
		Articulo a = lArticulos.get(row);
		if(column == 0) {
			return a.getId();
		}else if(column == 1) {
			return a.getNom();
		}else if(column == 2) {
			return a.getSeccion();
		}else if(column == 3) {
			return a.getEstanteria();
		}else if(column == 4) {
			return a.getPrecio();
		}else {
			return null;
		}
	}
	
	
	

}











import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class GestorTienda {
	private ArrayList<Articulo> lArticulos;
	
	public GestorTienda() {
		lArticulos = new ArrayList<Articulo>();
	}
	
	public void cargarArticulos(String nom) {
		File f = new File(nom);
		if(f.exists()) {
			try {
				Scanner sc = new Scanner(f);
				sc.nextLine();
				while(sc.hasNextLine()) {
					String linea = sc.nextLine();
					String [] campos = linea.split(";");
					int id = Integer.parseInt(campos[0]);
					String nombre = campos[1];
					Seccion seccion = Seccion.valueOf(campos[2]);
					int estanteria = Integer.parseInt(campos[3]);
					float precio = Float.parseFloat(campos[4]);
					Articulo a = new Articulo(id, nombre, seccion, precio, estanteria);
					lArticulos.add(a);
				}
				sc.close();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}
	}

	public ArrayList<Articulo> getlArticulos() {
		return lArticulos;
	}
}


public enum Seccion {
	A,B,C,D
}


public class Principal {
	
	public static void main(String[] args) {
		GestorTienda gt = new GestorTienda();
		gt.cargarArticulos("files/articulos_100.csv");
		new Ventana(gt.getlArticulos());
	}
}

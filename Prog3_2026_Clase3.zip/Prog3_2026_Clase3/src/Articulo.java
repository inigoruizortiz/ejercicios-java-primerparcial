
public class Articulo {
	private int id;
	private String nom;
	private Seccion seccion; //Sección en la que se encuentra el artículo dentro del almacén
	private int estanteria; //Número de la estantería en la que se guarda el artículo en el almacén (De 1 a 10)
	private double precio;
	
	public Articulo() {
		super();
	}
	public Articulo(int id, String nom, Seccion seccion, double precio, int estanteria ) {
		super();
		this.id = id;
		this.nom = nom;
		this.seccion = seccion;
		this.precio = precio;
		this.estanteria = estanteria;
	}
	
	public int getEstanteria() {
		return estanteria;
	}
	public void setEstanteria(int estanteria) {
		this.estanteria = estanteria;
	}
	public double getPrecio() {
		return precio;
	}
	public void setPrecio(double precio) {
		this.precio = precio;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public Seccion getSeccion() {
		return seccion;
	}
	public void setSeccion(Seccion seccion) {
		this.seccion = seccion;
	}
	@Override
	public String toString() {
		return "Articulo [id=" + id + ", nom=" + nom + ", seccion=" + seccion + ", estanteria=" + estanteria
				+ ", precio=" + precio + "]";
	}
	
	
	
	

}

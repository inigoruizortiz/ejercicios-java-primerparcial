import java.awt.BorderLayout;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class Ventana extends JFrame{
	private JPanel pNorte;
	private ArrayList<Articulo> listaArticulos;
	//Para crear una tabla declaramos al menos 2 atributos
	private ModeloTablaArticulos modeloTabla;
	private JTable tabla;
	private JScrollPane scrollTabla;
	
	public Ventana(List<Articulo> la) {
		super();
		
		listaArticulos = (ArrayList<Articulo>) la;
		//A partir de este momento, todo lo que tengamos que hacer con los artículos
		//lo haremos desde el atributo listaArticulos
		
		//Propiedades de la ventana
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setBounds(300, 300, 600, 300);
		
		//Creación de paneles
		pNorte = new JPanel();
		getContentPane().add(pNorte, BorderLayout.NORTH);
		
		//Creación de componentes
		modeloTabla = new ModeloTablaArticulos(listaArticulos);
		tabla = new JTable(modeloTabla);
		scrollTabla = new JScrollPane(tabla);
		//Añadir el scroll horizontal
		//scrollTabla.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scrollTabla.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		
		//Modificar el ancho de las columnas
		tabla.getColumnModel().getColumn(0).setPreferredWidth(10);
//		tabla.getColumnModel().getColumn(1).setPreferredWidth(30);
//		tabla.getColumnModel().getColumn(2).setPreferredWidth(10);
//		tabla.getColumnModel().getColumn(3).setPreferredWidth(60);
//		tabla.getColumnModel().getColumn(4).setPreferredWidth(20);
		
		//Impedir que se reorganicen las columnas
		tabla.getTableHeader().setReorderingAllowed(false);
		
		//Modificar el alto de las filas
		tabla.setRowHeight(30);
		
		//Modificar el color de fondo de la cabecera
		tabla.getTableHeader().setBackground(Color.LIGHT_GRAY);
		
		//Modificar el color de la fuente de la cabecera
		//tabla.getTableHeader().setForeground(Color.BLUE);
		
		//Si nos dan los valores RGB
		tabla.getTableHeader().setForeground(new Color(100, 100, 100)); //3 valores comprendidos entre 0 y 255
		
		add(scrollTabla, BorderLayout.CENTER);
		
		
		setVisible(true);
		
	}

}











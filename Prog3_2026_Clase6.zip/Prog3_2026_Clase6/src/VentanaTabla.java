import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellRenderer;

public class VentanaTabla extends JFrame{
	/*Declaración de atributos para una JTable con un modelo propio*/
	private ModeloTablaPersonas modeloTabla;
	private JTable tabla;
	private JScrollPane scrollTabla;
	
	private List<Persona> lp;
	
	public VentanaTabla(List<Persona> lp) {
		super();
		setBounds(300, 200, 600, 400);
		//setExtendedState(MAXIMIZED_BOTH);
		
		this.lp = lp;
		
		/*Instanciamos los atributos de la tabla y los añadimos a la ventana*/
		modeloTabla = new ModeloTablaPersonas(this.lp);
		tabla = new JTable(modeloTabla);
		scrollTabla = new JScrollPane(tabla);
	
		getContentPane().add(scrollTabla, BorderLayout.CENTER);
		
		
		/*RENDERER DE LA JTABLE*/
		/*Si la nota es >=9, color VERDE
		 *Si la nota es >=5, color AMARILLO
		 *Si la nota es <5, color ROJO
		 *
		 *La columna del DNI aparezca justificada a la izda
		 *La columna del NOMBRE aparezca centrada
		 *La columna de la NOTA MEDIA aparezca justificada a la dcha
		 **/
		
		tabla.setDefaultRenderer(Object.class, new TableCellRenderer() {
			
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,
					int row, int column) {
				// table      -> La tabla que contiene la información
				// value      -> El valor que haya en la celda en la que esté el renderer en este momento
				// isSelected -> Valdrá true si la celda está seleccionada
				// hasFocus   -> Valdrá true si la celda tiene el foco
				// row        -> La fila en la que está la celda (La primera fila de la tabla es la 0)
				// column     -> La columna en la que está la celda (La primera columna de la tabla es la 0)
				
				JLabel label = new JLabel(value.toString());
				if(column == 0) {
					label.setHorizontalAlignment(JLabel.LEFT);
				}else if(column == 1) {
					label.setHorizontalAlignment(JLabel.CENTER);
				}else if(column == 2) {
//					label.setHorizontalAlignment(JLabel.RIGHT);
//					float notaMedia = (float)value;
//					if(notaMedia >= 9) {
//						label.setForeground(Color.GREEN);
//					}else if(notaMedia >= 5) {
//						label.setForeground(Color.YELLOW);
//					}else {
//						label.setForeground(Color.RED);
//					}
					JProgressBar pb = new JProgressBar(0, 100);
					int nota = (int) (((float)value) * 10);
					pb.setValue(nota);
					pb.setStringPainted(true);
					pb.setBackground(Color.LIGHT_GRAY);
					pb.setForeground(Color.BLACK);
					return pb;
				}
				return label;
			}
		});
		
		//Modificar el renderer de la cabecera de la tabla
		//Fondo gris oscuro
		//Color de letra blanco
		//Títulos centrados
		tabla.getTableHeader().setDefaultRenderer(new TableCellRenderer() {
			
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,
					int row, int column) {
				JLabel label = new JLabel(value.toString());
				label.setOpaque(true);
				label.setBackground(Color.DARK_GRAY);
				label.setForeground(Color.WHITE);
				label.setHorizontalAlignment(JLabel.CENTER);
				return label;
			}
		});
		
		//La altura de todas las filas tiene que ser 30
		tabla.setRowHeight(30);
		//La anchura de la columan 0 tiene que ser 10
		tabla.getColumnModel().getColumn(0).setPreferredWidth(10);
		//Evitar que las columnas puedas cambiarse de sitio
		tabla.getTableHeader().setReorderingAllowed(false);
		setVisible(true);
	}
	
	
	public static void main(String[] args) {
		List<Persona> lp = new ArrayList<>();
		lp.add(new Persona("111A", "A", 5.9f));
		lp.add(new Persona("111B", "B", 9.9f));
		lp.add(new Persona("111C", "C", 8.9f));
		lp.add(new Persona("111D", "D", 7.9f));
		lp.add(new Persona("111E", "E", 2.9f));
		lp.add(new Persona("111F", "F", 9.9f));
		lp.add(new Persona("111G", "G", 8.9f));
		lp.add(new Persona("111H", "H", 8.9f));
		lp.add(new Persona("111I", "I", 4.0f));
		new VentanaTabla(lp);
	}
}
















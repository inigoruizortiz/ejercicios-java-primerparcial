import java.util.Arrays;
import java.util.List;

import javax.swing.table.DefaultTableModel;

public class ModeloTablaPersonas extends DefaultTableModel{
	private List<String> lTitulos = Arrays.asList("DNI","NOMBRE","NOTA MEDIA");
	private List<Persona> lPersonas;
	
	public ModeloTablaPersonas(List<Persona> l) {
		this.lPersonas = l;
	}

	@Override
	public int getRowCount() {
		if(this.lPersonas == null) {
			return 0;
		}
		return lPersonas.size(); //La tabla va a tener tantas filas como personas haya en la lista
	}

	@Override
	public int getColumnCount() {
		return this.lTitulos.size(); //La tabla va tener tantas columnas como títulos hay en la lista de títulos
	}

	@Override
	public String getColumnName(int column) {
		return this.lTitulos.get(column);
	}

	@Override
	public boolean isCellEditable(int row, int column) {
		return false;
	}

	@Override
	public Object getValueAt(int row, int column) {
		Persona p = this.lPersonas.get(row);
		switch(column) {
			case 0: return p.getDni();
			case 1: return p.getNombre();
			case 2: return p.getNotaMedia();
			default: return null;
		}
	}
	
	
	
	
}

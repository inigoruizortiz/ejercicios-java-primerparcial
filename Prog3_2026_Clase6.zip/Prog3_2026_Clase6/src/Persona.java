
public class Persona {
	private String dni;
	private String nombre;
	private float notaMedia;
	
	public Persona() {
		super();
	}
	
	public Persona(String dni, String nombre, float notaMedia) {
		super();
		this.dni = dni;
		this.nombre = nombre;
		this.notaMedia = notaMedia;
	}
	
	public String getDni() {
		return dni;
	}
	public void setDni(String dni) {
		this.dni = dni;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public float getNotaMedia() {
		return notaMedia;
	}
	public void setNotaMedia(float notaMedia) {
		this.notaMedia = notaMedia;
	}
	@Override
	public String toString() {
		return "Persona [dni=" + dni + ", nombre=" + nombre + ", notaMedia=" + notaMedia + "]";
	}
	
	
}

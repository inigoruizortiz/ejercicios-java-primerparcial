import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;

public class Ventana extends JFrame{
	private JLabel lblTitulo;
	private JButton btnBoton;
	private JPanel pNorte, pSur, pEste, pOeste, pCentro;
	private boolean click;
	
	public Ventana() {
		super();
		
		//PROPIEDADES DE LA VENTANA
		setBounds(400, 200, 600, 400);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		click = false;
		setResizable(false); //La ventana no se puede redimensionar
		setTitle("MI PRIMERA VENTANA");
		//Modificar el icono de la ventana
		ImageIcon im = new ImageIcon("img/titulo.png");
		setIconImage(im.getImage());
		
		//CREACIÓN DE PANELES
		//El Layout por defecto que cualquier panel que no sea el panel principal de la ventana, es FlowLayout
		pNorte = new JPanel();
		pNorte.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED, Color.BLACK, Color.PINK));
		pSur = new JPanel();
		pEste = new JPanel();
		pOeste = new JPanel();
		pCentro = new JPanel();
		//Modificar el Layout del panel centro
		// número de filas, número de columnas, espacio horizontal y espacio vertical 
		pCentro.setLayout(new GridLayout(5, 8, 5, 20));
		
		//AÑADIR PANELES A LA VENTANA
		add(pNorte, BorderLayout.NORTH);
		add(pSur, BorderLayout.SOUTH);
		add(pEste, BorderLayout.EAST);
		add(pOeste, BorderLayout.WEST);
		add(pCentro, BorderLayout.CENTER);
		
		//CREACIÓN DE COMPONENTES
		btnBoton = new JButton("BOTÓN");
		for(int i=1;i<=5*8;i++) {
			JLabel l = new JLabel(String.valueOf(i));
			l.setHorizontalAlignment(JLabel.CENTER);
			l.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY, 4));
			pCentro.add(l);
		}
		lblTitulo = new JLabel("ONGI ETORRI!!");
		// tipo de letra, formato (BOLD, ITALIC, PLAIN), tamaño
		lblTitulo.setFont(new Font(Font.DIALOG, Font.BOLD, 18));
		// Modificar el color de la letra
		//lblTitulo.setForeground(Color.GREEN);
		lblTitulo.setForeground(new Color(130, 240, 200));
		//Modificar el color de fondo de la etiqueta (Cuidado! Una etiqueta es, por defecto, transparente
		lblTitulo.setOpaque(true);
		lblTitulo.setBackground(Color.YELLOW);
		
		//AÑADIR COMPONENTES A LOS PANELES/VENTANA
		pSur.add(btnBoton);
		pNorte.add(lblTitulo);
		
		//LISTENERS
		btnBoton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// Aquí tenemos que escribir el código a ejecutar cuando se clicke el botón
				// Vamos a cambiar el color del fondo del panel cebtro
				// Cada vez que clicke cambiamos de CYAN a WHITE
				if(!click){     //if(click == false) {
					pCentro.setBackground(Color.CYAN);
					click = true;
				}else {
					pCentro.setBackground(Color.WHITE);
					click = false;
				}
				
			}
		});
		
		setVisible(true);
	}
	
	public static void main(String[] args) {
		new Ventana();
	}
	
}

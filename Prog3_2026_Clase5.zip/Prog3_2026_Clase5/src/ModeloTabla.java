import java.util.Arrays;
import java.util.List;

import javax.swing.table.DefaultTableModel;

public class ModeloTabla extends DefaultTableModel{
	private List<String> lTitulos = Arrays.asList("NOMBRE","UNIDADES","PRECIO");
	private List<Producto> lProductos;
	
	public ModeloTabla(List<Producto> l) {
		this.lProductos = l;
	}

	@Override
	public int getRowCount() {
		if(this.lProductos == null) {
			return 0;
		}
		return lProductos.size();
	}

	@Override
	public int getColumnCount() {
		return lTitulos.size();
	}

	@Override
	public String getColumnName(int column) {
		return lTitulos.get(column);
	}

	@Override
	public boolean isCellEditable(int row, int column) {
		return false;
	}

	@Override
	public Object getValueAt(int row, int column) {
		Producto p = this.lProductos.get(row);
		switch (column) {
			case 0: return p.getNombre();
			case 1: return p.getUnidades();
			case 2: return p.getPrecio();
			default: return null;
		}
	}
	
	
}







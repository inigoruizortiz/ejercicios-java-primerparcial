import java.awt.BorderLayout;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JSlider;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTree;
import javax.swing.SpinnerModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;


public class Ventana extends JFrame{
	private JPanel pNorte;
	
	//JList
	private DefaultListModel<String> modeloLista;
	private JList<String> lista;
	private JScrollPane scrollLista;
	
	//JTable
	private ModeloTabla modeloTabla;
	private JTable tabla;
	private JScrollPane scrollTabla;
		
	//JSlider
	private JSlider slPrecio;
	
	//JSpinner
	private JSpinner spUnidades;
	
	
	public Ventana() {
		super();
		setBounds(300, 200, 600, 400);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		//CREACIÓN DE PANELES
		pNorte = new JPanel();
		getContentPane().add(pNorte,BorderLayout.NORTH);
		
		//CREACIÓN DE COMPONENTES
		//JList
		modeloLista = new DefaultListModel<String>();
		//Cargar los nombres de los supermercados en el modelo de la lista
		for(String nombre: CadenaSupermercados.getMapaProductos().keySet()) { //Recorremos las claves del mapa (nombres de los supercados)
			modeloLista.addElement(nombre); //Añadimos cada nombre al modelo de la lista
		}
		lista = new JList<String>(modeloLista);
		scrollLista = new JScrollPane(lista);
		add(scrollLista, BorderLayout.WEST);
		
		
		//JTable
		modeloTabla = new ModeloTabla(null);
		tabla = new JTable(modeloTabla);
		scrollTabla = new JScrollPane(tabla);
		add(scrollTabla, BorderLayout.CENTER);
		
		//JSlider
		// valor mínimo, valor máximo, valor actual
		slPrecio = new JSlider(0, 10, 0);
		slPrecio.setMinorTickSpacing(1);
		slPrecio.setMajorTickSpacing(1);
		slPrecio.setPaintLabels(true);
		slPrecio.setPaintTicks(true);
		pNorte.add(slPrecio);
		
		//JSpinner
		//            valor inicial, valor mínimo, valor máximo, salto
		spUnidades = new JSpinner(new SpinnerNumberModel(1, 0, 100, 1));
		pNorte.add(spUnidades);
		
		//Listeners
		slPrecio.addChangeListener(new ChangeListener() {
			
			@Override
			public void stateChanged(ChangeEvent e) {
				//Queremos que en la tabla aparezca aquellos productos del supermercado seleccionado y
				//cuyo precio sea como máximo el seleccionado en el slPrecio
				float precio = slPrecio.getValue();
				
			}
		});
		
		spUnidades.addChangeListener(new ChangeListener() {
			
			@Override
			public void stateChanged(ChangeEvent e) {
				//Mostrar en la tabla aquellos productos del supermercado seleccionado y que además tengan
				//como mínimo tantas unidades como hayamos indicado en el spUnidades
				
				//Obtenemos el número de unidades seleccionadas en el spUnidades
				int unidades = (int) spUnidades.getValue();
				
				//Obtener el nombre del supermercado seleccionado
				String nombre = lista.getSelectedValue();
				
				//Obtener la lista de productos del supermercado seleccionado
				List<Producto> lProductos = CadenaSupermercados.obtenerListaProductos(nombre);
				
				//De esta lista vamos a quedarnos con aquellos productos que tengan al menos "unidades" unidades
				List<Producto> lProductosFiltrados = new ArrayList<Producto>();
				for(Producto p: lProductos) {
					if(p.getUnidades() >= unidades) {
						lProductosFiltrados.add(p);
					}
				}
				
				//Volvemos a crear el modelo con la nueva información
				modeloTabla = new ModeloTabla(lProductosFiltrados);
				//Le asignamos a la tabla el nuevo modelo
				tabla.setModel(modeloTabla);
			}
		});
		
		
		
		lista.addListSelectionListener(new ListSelectionListener() {
			
			@Override
			public void valueChanged(ListSelectionEvent e) {
				//Vamos a obtener el nombre del supermercado en el que ha hecho click
				String nombre = lista.getSelectedValue();
				//Vamos a obtener la lista de productos asociada a ese supermercado
				List<Producto> lProductos = CadenaSupermercados.obtenerListaProductos(nombre);
				//Volvemos a crear el modelo con esta lista de productos
				modeloTabla = new ModeloTabla(lProductos);
				//Le asignamos el nuevo modelo a la tabla
				tabla.setModel(modeloTabla);
				
			}
		});
		
		//Renderers
		
		setVisible(true);
	}
	
	public static void main(String[] args) {
		CadenaSupermercados.cargarFicheroEnMapa("ficheros/productos.csv");
		new Ventana();
	}
}



























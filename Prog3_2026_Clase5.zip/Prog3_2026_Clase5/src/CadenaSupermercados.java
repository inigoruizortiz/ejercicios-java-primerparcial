import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

/*Cuando un método es static se utiliza desde la clase
 * 
 * CadenaSupermercados.obtenerListaProductos*/

public class CadenaSupermercados {
	/*Mapa de clave nombre del Supermercado y valor conjunto de los productos que se venden en ese supermercado*/
	private static Map<String, Set<Producto>> mapaProductos = new TreeMap<>();

	/*Método que recibe el nombre de un supermercado y devuelve una lista con todos los
	 * productos del supermercado*/
	public static List<Producto> obtenerListaProductos(String supermercado){
		List<Producto> listaProductos = new ArrayList<>();
		for(Producto p: mapaProductos.get(supermercado)) {
			listaProductos.add(p);
		}
		return listaProductos;
	}
	
	public static Map<String, Set<Producto>> getMapaProductos() {
		return mapaProductos;
	}
	
	public static void cargarFicheroEnMapa(String nomfich) {
		try {
			Scanner sc = new Scanner(new FileReader(nomfich));
			String titulos = sc.nextLine();
			String linea;
			while(sc.hasNext()) {
				linea = sc.nextLine();
				String [] partes = linea.split(";");
				String supermecardo = partes[0];
				String producto = partes[1];
				int unidades = Integer.parseInt(partes[2]);
				float precio = Float.parseFloat(partes[3]);
				Producto p = new Producto(producto, unidades, precio);
				if(!mapaProductos.containsKey(supermecardo)) {
					mapaProductos.put(supermecardo, new TreeSet<>());
				}
				mapaProductos.get(supermecardo).add(p);
			}
			sc.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

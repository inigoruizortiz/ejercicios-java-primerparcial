import java.awt.BorderLayout;
import java.awt.Component;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.TableCellRenderer;

public class Ventana2 extends JFrame{
	
	private List<Articulo> lArticulos;
	
	private ModeloMatrizArticulos modelo;
	private JTable tabla;
	private JScrollPane scroll;
	
	public Ventana2(List<Articulo> la) {
		super();
		
		this.lArticulos = la;
		setBounds(300, 300, 1000, 200);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		//Creación de componentes
		modelo = new ModeloMatrizArticulos(this.lArticulos);
		tabla = new JTable(modelo);
		scroll = new JScrollPane(tabla);
		add(scroll, BorderLayout.CENTER);
		
		//Renderer de la tabla
		//Aparezca sólo el nombre del artículo o si en la celda no hay nada un -
		tabla.setDefaultRenderer(Object.class, new TableCellRenderer() {
			
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,
					int row, int column) {
				JLabel l = new JLabel();
				if(value == null) {
					l.setText(" - ");
				}else {
					if(value instanceof Seccion) {
						l.setText(value.toString());
					}else {
						Articulo a = (Articulo)value;
						l.setText(a.getNom());
					}
				}
				return l;
			}
		});
		
		tabla.setRowHeight(30);
		
		setVisible(true);
	}
}

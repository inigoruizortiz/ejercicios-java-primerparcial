import java.util.Arrays;
import java.util.List;

import javax.swing.table.DefaultTableModel;

public class ModeloMatrizArticulos extends DefaultTableModel{
	private List<String> lTitulos = Arrays.asList("","E1","E2","E3","E4","E5","E6","E7","E8","E9","E10");
	private Object [][] matriz;
	
	public ModeloMatrizArticulos(List<Articulo> la) {
		//Creamos la matriz
		matriz = new Object[4][11];
		
		//Recorro las 4 filas de la matriz para cargar en la columna 0, las secciones
		for(int f=0;f<matriz.length;f++) {
			matriz[f][0] = Seccion.values()[f];
		}
		
		//Recorro la lista de artículos para cargar cada uno en la posición (fila,columna) correspondiente de la matriz
		for(Articulo a: la) {
			int columna = a.getEstanteria();
//			int fila ;
//			if(a.getSeccion().equals(Seccion.A)) {
//				fila = 0;
//			}else if(a.getSeccion().equals(Seccion.B)) {
//				fila = 1;
//			}else if(a.getSeccion().equals(Seccion.C)) {
//				fila = 2;
//			}else {
//				fila = 3;
//			}
			int fila = a.getSeccion().ordinal(); //Devuelve la posición de la enumeración (A-0, B-1, C-2, D-3)
			matriz[fila][columna] = a;
		}
		
		
	}

	@Override
	public int getRowCount() {
		if(matriz == null)
			return 0;
		return matriz.length;
	}

	@Override
	public int getColumnCount() {
		return lTitulos.size();
	}

	@Override
	public String getColumnName(int column) {
		return lTitulos.get(column);
	}

	@Override
	public boolean isCellEditable(int row, int column) {
		return false;
	}

	@Override
	public Object getValueAt(int row, int column) {
		return matriz[row][column];
	}
}

import java.util.Arrays;
import java.util.List;

import javax.swing.table.DefaultTableModel;

public class ModeloTablaArticulos extends DefaultTableModel{
	private List<String> lTitulos = Arrays.asList("ID","NOMBRE","SECCIÓN","ESTANTERÍA","PRECIO");
	private List<Articulo> lArticulos;
	
	public ModeloTablaArticulos(List<Articulo> la) {
		this.lArticulos = la;
	}

	@Override
	public int getRowCount() {
		//Devuelve el número de filas que tiene que tener la tabla
		if(this.lArticulos == null)
			return 0;
		return this.lArticulos.size(); //La tabla tendrá tantas filas como artículos haya en la lista de artículos
	}

	@Override
	public int getColumnCount() {
		//Devuelve el número de columnas que tiene la tabla
		return this.lTitulos.size(); //La tabla tendrá tantas columnas como títulos haya en la lista de títulos
	}

	@Override
	public String getColumnName(int column) {
		//Devuelve el título asociado a la columna que recibe por parámetro
		return this.lTitulos.get(column);
	}

	@Override
	public boolean isCellEditable(int row, int column) {
		//Devuelve true si la celda (row-column) es editable y false en caso contrario
//		if(column == 0) 
//			return true;
		return false;
	}

	@Override
	public Object getValueAt(int row, int column) {
		Articulo a = this.lArticulos.get(row);
		switch(column) {
			case 0: return a.getId();
			case 1: return a.getNom();
			case 2: return a.getSeccion();
			case 3: return a.getEstanteria();
			case 4: return a.getPrecio();
			default: return null;
		}
	}
	
	
			
}







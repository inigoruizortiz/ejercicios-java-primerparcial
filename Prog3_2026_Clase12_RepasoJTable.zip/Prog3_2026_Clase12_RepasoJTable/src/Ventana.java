import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.TableCellRenderer;

public class Ventana extends JFrame{
	private JPanel pNorte;
	private ArrayList<Articulo> listaArticulos;
	
	//Para trabajar con una JTable declaramos 3 atributos
	private ModeloTablaArticulos modelo;
	private JTable tabla;
	private JScrollPane scroll;
	
	public Ventana(List<Articulo> la) {
		super();
		
		listaArticulos = (ArrayList<Articulo>) la;
		//A partir de este momento, todo lo que tengamos que hacer con los artículos
		//lo haremos desde el atributo listaArticulos
		
		//Propiedades de la ventana
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setBounds(300, 300, 600, 300);
		
		//Creación de paneles
		pNorte = new JPanel();
		getContentPane().add(pNorte, BorderLayout.NORTH);
		
		//Creación de componentes
		modelo = new ModeloTablaArticulos(listaArticulos);
		tabla = new JTable(modelo);
		scroll = new JScrollPane(tabla);
		
		add(scroll, BorderLayout.CENTER);
		
		//Renderer de la JTable
		// Columna 0 esté justificada a la izda, la 4 a la dcha y el resto centradas
		// La celda Sección que tenga color de letra AZUL para la sección A, AMARILLO para la B, CYAN para la C y VERDE para la D
		tabla.setDefaultRenderer(Object.class, new TableCellRenderer() {
			
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,
					int row, int column) {
				JLabel l = new JLabel(value.toString());
				if(column == 0) {
					l.setHorizontalAlignment(JLabel.LEFT);
				}else if (column == 4) {
					l.setHorizontalAlignment(JLabel.RIGHT);
				}else {
					l.setHorizontalAlignment(JLabel.CENTER);
				}
				if(column == 2) {
					//Si estamos en la columna 2, sabemos que el value es una Sección
					Seccion s = (Seccion)value;
					if(s.equals(Seccion.A)) {
						l.setForeground(Color.BLUE);
					}else if(s.equals(Seccion.B)) {
						l.setForeground(Color.YELLOW);
					}else if(s.equals(Seccion.C)) {
						l.setForeground(Color.CYAN);
					}else {
						l.setForeground(Color.GREEN);
					}
				}
				return l;
			}
		});
		
		setVisible(true);
		
	}

}











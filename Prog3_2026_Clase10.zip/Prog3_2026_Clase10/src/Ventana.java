import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Ventana extends JFrame{
	private JPanel pCentro, pSur, pArriba, pAbajo, pIzda, pDcha;
	private JButton btnIniciar1, btnIniciar2;
	private Thread hilo1, hilo2;
	private JLabel lblNumero1, lblNumero2;
	
	private boolean pausa1, pausa2;
	private final Object monitor1 = new Object();
	private final Object monitor2 = new Object();
	public Ventana() {
		super();
		
		//Propiedades de la ventana
		setBounds(300, 300, 500, 300);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setResizable(false);
		
		//Creación de paneles
		//número de filas, número de columnas, espacio horizontal, espacio vertical
		pCentro = new JPanel(new GridLayout(2, 1, 30, 30));
		pSur = new JPanel(new GridLayout(1, 2, 30, 30));
		pArriba = new JPanel();
		pAbajo = new JPanel();
		pIzda = new JPanel();
		pDcha = new JPanel();
		
		//Le añadimos un borde a los paneles
		pCentro.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		pSur.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		pArriba.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		pAbajo.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		pIzda.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		pDcha.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		
		//Añadimos los paneles a la ventana
		add(pCentro, BorderLayout.CENTER);
		add(pSur, BorderLayout.SOUTH);
		pCentro.add(pArriba);
		pCentro.add(pAbajo);
		pSur.add(pIzda);
		pSur.add(pDcha);
		
		
		//Creación de componentes
		btnIniciar1 = new JButton("INICIAR 1");
		btnIniciar2 = new JButton("INICIAR 2");
		pIzda.add(btnIniciar1);
		pDcha.add(btnIniciar2);
		lblNumero1 = new JLabel();
		lblNumero2 = new JLabel();
		pArriba.add(lblNumero1);
		pAbajo.add(lblNumero2);
		
		//Creación de hilos
		pausa1 = true; //El hilo empieza en pausa
		
		hilo1 = new Thread(new Runnable() {
			
			@Override
			public void run() {
				int n = 1;
				while(true) {
					synchronized(monitor1) {
						if(pausa1==true) {
							try {
								monitor1.wait();
							} catch (InterruptedException e) {
								e.printStackTrace();
							}
						}else {
							lblNumero1.setText(String.valueOf(n));
							n++;
							try {
								Thread.sleep(1000);
							} catch (InterruptedException e) {
								e.printStackTrace();
							}
						}
					
					}
				}
			}
		});
		hilo1.start();
		
		pausa2 = true;
		hilo2 = new Thread(new Runnable() {
			
			@Override
			public void run() {
				int n = 50;
				while(true) {
					synchronized (monitor2) {
						if(pausa2 == true) {
							try {
								monitor2.wait();
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}else {
							lblNumero2.setText(String.valueOf(n));
							n--;
							try {
								Thread.sleep(500);
							} catch (InterruptedException e) {
								e.printStackTrace();
							}
						}
					}
				}
			}
		});
		hilo2.start();
		
		//Listeners
		btnIniciar1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				synchronized (monitor1) {
					if(btnIniciar1.getText().equals("INICIAR 1")) {
						pausa1 = false;
						btnIniciar1.setText("PAUSAR 1");
						monitor1.notifyAll();
					}else {
						pausa1 = true;
						btnIniciar1.setText("INICIAR 1");
						monitor1.notifyAll();
					}
				}
			}
		});
		
		btnIniciar2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				synchronized (monitor2) {
					if(btnIniciar2.getText().equals("INICIAR 2")) {
						pausa2 = false;
						btnIniciar2.setText("PAUSAR 2");
						monitor2.notifyAll();
					}else {
						pausa2 = true;
						btnIniciar2.setText("INICIAR 2");
						monitor2.notifyAll();
					}
				}
				
			}
		});
		setVisible(true);
	}
	
	public static void main(String[] args) {
		new Ventana();
	}
}











